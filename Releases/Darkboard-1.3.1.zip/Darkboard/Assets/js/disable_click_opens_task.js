document.addEventListener('DOMContentLoaded', () => {

	KB.onClick('.task-board *', () => {}, true);

});
