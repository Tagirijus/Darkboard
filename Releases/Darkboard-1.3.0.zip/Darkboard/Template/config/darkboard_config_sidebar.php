<li <?= $this->app->checkMenuSelection('DarkboardController', 'show') ?>>
    <a href="/darkboard/config"><?= t('Darkboard configuration') ?></a>
</li>
